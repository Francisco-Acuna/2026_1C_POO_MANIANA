package ar.org.centro8.java.curso.tests;

import ar.org.centro8.java.curso.entidades.encapsulamiento.Empleado;

public class TestEncapsulamiento {
    public static void main(String[] args) {
        
        //creamos un objeto de Empleado
        // Empleado empleado1 = new Empleado(); ERROR -> no tenemos constructor vacío declarado en la clase Empleado.
        Empleado empleado1 = new Empleado(1, "Arnold", "Schaurseneguer", "casado", 100);
        System.out.println(empleado1);


    }
}
