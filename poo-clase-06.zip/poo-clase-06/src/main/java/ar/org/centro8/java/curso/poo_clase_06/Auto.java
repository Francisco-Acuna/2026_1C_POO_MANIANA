package ar.org.centro8.java.curso.poo_clase_06;

public class Auto {
    //una clase es una plantilla o molde que define los atributos y métodos que tendrán los objetos
    //las clases se denominan como sustantivos en singular y con PascalCase

    //atributos
    //definimos los atributos o propiedades (son variables que indican las características)
    String marca;
    String modelo;
    String color;
    int velocidad;

    //constructores
    //si no declaramos un constructor, se crea uno vacío por defecto.
    //los métodos constructores llevan el mismo nombre de la clase y llevan los paréntesis porque son métodos.

    //constructor vacío
    Auto(){}
    //si declaramos constructores con parámetros debemos declarar el vacío explícitamente si lo queremos usar

    //constructor completo (recibe todos los atributos como argumentos)
    Auto(String marca, String modelo, String color, int velocidad){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.velocidad = velocidad;
    }

    //sobrecarga de constructores
    Auto(String marca, String modelo, String color){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;
    }

    //más sobrecarga
    /**
     * Constructor para los autos de la marca Ford
     * @param modelo
     * @param color
     */
    Auto(String modelo, String color){
        this.marca = "Ford";
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;
    }

    //métodos
    //definimos los métodos (son bloques de código que definen el comportamiento del objeto)
    void acelerar(){
        velocidad += 10;
    }

    void frenar(){
        velocidad -= 10;
    }

    //sobrecarga de métodos
    //se da cuando un método tiene el mismo nombre que otro existente pero cambia la cantidad y/o tipo de parámetros

    void acelerar(int kilometros){
        velocidad += kilometros;
    }

    /**
     * Este método incrementa la velocidad en la cantidad de kilómetros ingresados.
     * Si el turbo es true, incrementa el doble de la velocidad
     * @param kilometros -> cantidad de kilómetros a incrementar
     * @param turbo -> si es true, incrementa el doble de kilómetros
     */
    void acelerar(int kilometros, boolean turbo){
        if(turbo){
            velocidad += kilometros * 2;
        }else{
            velocidad += kilometros;
        }
    }

    void imprimirVelocidad(){
        System.out.println(velocidad);
    }

    int obtenerVelocidad(){
        return velocidad;
    }

    @Override
    public String toString(){
        return "Auto: marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", velocidad=" + velocidad + ".";
    }


}
