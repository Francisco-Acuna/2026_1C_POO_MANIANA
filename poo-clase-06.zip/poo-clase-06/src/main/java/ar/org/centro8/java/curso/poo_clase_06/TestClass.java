package ar.org.centro8.java.curso.poo_clase_06;

public class TestClass {
    public static void main(String[] args) {
        
        //creamos un objeto de la clase Auto
        Auto auto1 = new Auto();
        //un objeto es una instancia de una clase, es decir, una entidad con características (atributos)
        //y comportamiento (métodos)

        //le damos estado al objeto (dar estado es completar el valor de sus atributos)
        auto1.marca = "Fiat";
        auto1.modelo = "Fiorino";
        auto1.color = "Blanco";
        auto1.velocidad = 0;

        //ver los valores de los atributos del objeto
        System.out.println(auto1.marca);
        System.out.println(auto1.modelo);
        System.out.println(auto1.color);
        System.out.println(auto1.velocidad);

        //utilizamos los métodos de la clase
        auto1.acelerar(); // 10
        System.out.println(auto1.velocidad); // 10

        auto1.acelerar(); // +10 = 20
        auto1.acelerar(); // +10 = 30
        auto1.frenar(); // -10 = 20
        System.out.println(auto1.velocidad); //20

        System.out.println();

        //creamos un nuevo auto
        Auto auto2 = new Auto();
        auto2.marca = "Citroën";
        auto2.modelo = "C4";
        auto2.color = "Fucsia";
        auto2.velocidad = 0;

        //imprimimos el estado del objeto
        System.out.println("Auto1: marca=" + auto2.marca + ", modelo=" + auto2.modelo + ", color=" + auto2.color + ", velocidad=" + auto2.velocidad);

        auto2.acelerar(35); //35
        auto2.acelerar(10, true); //55
        auto2.imprimirVelocidad();

        for (int i = 1; i <= 10; i++) {
            auto2.acelerar();
        }
        System.out.println("La velocidad actual es: " + auto2.obtenerVelocidad()); //155

        //método toString()
        //es un método heredado de la clase Object.
        //Proporciona una representación del objeto en forma de cadena de texto
        System.out.println(auto2.toString());
        //por defecto devuelve una cadena con el nombre de la clase seguido de un @ y el código hash
        System.out.println(auto1.toString());

        //creamos otro auto con constructor completo
        Auto auto3 = new Auto("Chevrolet", "Corsa", "Rosa", 0);
        System.out.println(auto3); //si solo ponemos el nombre del objeto llamará al toString()

        Auto auto4 = new Auto("Volkswagen", "GolGol", "Celeste");
        System.out.println(auto4);

        Auto auto5 = new Auto("Taunus", "Rojo fuego");
        System.out.println(auto5);

    }
}
