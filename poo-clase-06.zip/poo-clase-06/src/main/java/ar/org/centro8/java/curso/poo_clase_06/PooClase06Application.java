package ar.org.centro8.java.curso.poo_clase_06;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PooClase06Application {

	public static void main(String[] args) {
		SpringApplication.run(PooClase06Application.class, args);
	}

}
