package ar.org.centro8.java.curso.poo_clase_05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PooClase05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
