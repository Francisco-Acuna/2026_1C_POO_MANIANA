package ar.org.centro8.java.curso.entidades.relaciones;

import lombok.Data;

@Data
public class Cuenta {
    private final int nro;
    private final String moneda;
    private float saldo;

    // al colocar la palabra reservada final, hacemos que la variable quede constante, por lo tanto su valor
    // no podrá cambiar nunca.
    // Los tipos de datos primitivos no son nulleables. No admiten valores nulos.
    // Los tipos de datos enteros se inicializan en 0
    // Los tipos de datos con decimales se inicializan en 0.0

    
}
