import java.util.Scanner;

public class Clase04 {
    public static void main(String[] args) {
        
        //Estructuras

        //condicionales

        //if
        int numero1 = 100;
        int numero2 = 20;

        if(numero1 > numero2){
            System.out.println("El número 1 es mayor que el número 2");
        }

        //si solo se ejecuta una sentencia en el cuerpo del IF, lo podemos hacer en línea
        if(numero1 > numero2) System.out.println("El número 1 es mayor que el número 2");

        //cuando ejecutamos más de una sentencia, debemos utilizar las llaves
        if (numero1 > numero2) {
            System.out.println("El número 1 es mayor que el número 2");
            int suma = numero1 + numero2;
            System.out.println("El resultado de la suma de ambos números es " + suma);
        }

        //if-else
        if (numero1 > numero2) {
            System.out.println("El número 1 es mayor que el número 2");
        } else {
            System.out.println("El número 1 no es mayor que el número 2");
        }

        //if-else en línea
        if(numero1 > numero2) System.out.println("El número 1 es mayor que el número 2");
        else System.out.println("El número 1 no es mayor que el número 2");

        //if-else anidado
        int edad = 22;
        boolean tienePasaporte = true;

        if (tienePasaporte) {
            if (edad >= 18) {
                System.out.println("Puede viajar solo");
            } else {
                System.out.println("Puede viajar, pero acompañado de un adulto.");
            }
        } else {
            System.out.println("No puede viajar.");
        }

        //operador ternario (if-else abreviado)
        //condición ? valorSiVerdadero : valorSiFalso

        String mensaje = (edad >= 18) ? "Mayor de edad" : "Menor de edad";
        System.out.println(mensaje);

        //estructura switch case
        int dia = 3;

        switch(dia){
            case 1: System.out.println("Lunes"); break;
            case 2: System.out.println("Martes"); break;
            case 3: System.out.println("Miércoles"); break;
            case 4: System.out.println("Jueves"); break;
            case 5: System.out.println("Viernes"); break;
            case 6: System.out.println("Sábado"); break;
            case 7: System.out.println("Domingo"); break;
            default: System.out.println("El día no es válido"); //opcional
        }

        switch(dia){
            case 1,2,3,4,5: System.out.println("Es día de semana."); break;
            case 6,7: System.out.println("Es fin de semana."); break;
            default: System.out.println("No es un día válido");
        }

        // rule switch - JDK 14
        // se reemplazan los : por las -> y desaparecen los break
        // además se puede utilizar la estructura como una expresión

        String diaSemana = switch(dia){
            case 1 -> "Lunes";
            case 2 -> "Martes";
            case 3 -> "Miércoles";
            case 4 -> "Jueves";
            case 5 -> "Viernes";
            case 6 -> "Sábado";
            case 7 -> "Domingo";
            default -> "Día no válido";
        };

        System.out.println(diaSemana);

        // Estructuras repetitivas

        //while
        int contador = 1;
        while (contador <= 10){
            System.out.println(contador);
            contador++;
        }

        //do-while con break y continue
        int numero;
        int suma = 0;
        Scanner teclado = new Scanner(System.in);
        //Scanner es una clase que me permite leer datos desde la consola

        System.out.println("\n#########################################\n");
        System.out.println("Se sumarán los números enteros, pares, positivos.");
        System.out.println("Siempre y cuando la suma no supere los 100");

        do {
            System.out.println("Ingrese un número entero para sumar o el 0 para salir:");
            numero = teclado.nextInt();
            if(numero % 2 != 0) continue;
            if(numero > 0) suma += numero;
            if(suma > 100) break;
        } while(numero != 0);
        System.out.println("La suma de números enteros pares positivos es de: " + suma);

        //for
        for (int i = 0; i < args.length; i++) {
            System.out.println(i);
        }

    }
}
