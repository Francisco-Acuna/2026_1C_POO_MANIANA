public class Clase03 {
    public static void main(String[] args) {
        
        /*
        Instituto: Centro de Formación Profesional N°8 - SMATA
        Curso: Programación Orientada a Objetos
        Lenguaje principal: Java
        Cursada: lunes, miércoles y viernes de 10 a 13.30hs.
        Profesor: Francisco Acuña
        Email: franciscoacuna.centro8@gmail.com
        Repositorio: https://github.com/Francisco-Acuna/2026_1C_POO_MANIANA
        Softwares necesarios:
            - JDK (sugerido 21 o 17) -> https://www.oracle.com/latam/java/technologies/downloads/#java21
            - Visual Studio Code -> https://code.visualstudio.com/download
            - Extension de VSC -> Extension Pack for Java (by Microsoft)
            - MySQL y Workbench -> https://www.mysql.com/downloads/
        */

        // comentario en línea
        
        /*
            comentarios 
            en bloque
            (varias líneas)
        */

        /**
         * comentarios del tipo
         * JavaDoc
         * en bloque
         */

        //etiquetas en los comentarios

        // TODO indican tareas pendientes por implementar o finalizar

        // FIXME señala los errores o problemas que deben ser corregidos

        // instalar extensión TODO TREE by Gruntfuggly

        //impresión por consola
        System.out.println("Hola Mundo!");
        // sout + tab (atajo de teclado para impresión por consola)

        //declaración de variable
        int variable; //declaración de variable con tipo de dato e identificador
        variable = 10; //asignación de valor a la variable
        int variable2 = 10; //declaración y asignación en línea
        int variable3=10, variable4=20, variable5=30; //declaración y asignación múltiple en línea
        
        /*
            Java es un lenguaje fuertemente tipado, por lo cual se deben respetar ciertos puntos:
            - No se puede asignar otro tipo de dato como valor a una variable ya declarada.
            - No se puede cambiar el tipo de dato de una variable ya declarada.
            - No se puede crear otra variable con el mismo nombre.
            - Una variable puede tener una única declaración.
            - Una variable puede tener innumerables valores, siempre que sean del mismo tipo de dato.
        */

        // ** Tipos de datos primitivos **

        // byte -> ocupa 1 byte y representa un número entre -128 y 127
        byte variableByte = 100;
        // byte variableByte = 1000; ERROR porque no puedo representar ese número, excede el rango.
        System.out.println(variableByte);

        // short -> ocupa 2 bytes y representa un número entero entre -32.768 y 32.767
        short variableShort = 12456;
        System.out.println(variableShort);

        // int -> ocupa 4 bytes -> representa un número entero entre -2.147.483.648 y 2.147.483.647 
        // es el tipo de datos más utilizado para números sin decimales, es el standard por defecto
        int variableInt = 151613;
        System.out.println(variableInt);

        // long -> ocupa 8 bytes -> representa un número muy grande que va desde -2 elevado a la 63 hasta el 2
        //elevado a la 63 -1
        // se utiliza solo para representar números muy muy grandes
        long variableLong = 2156161341654123542L;
        //debe llevar una L al final. Usamos la L mayúscula porque la l minúscula parace un 1
        System.out.println(variableLong);

        // float -> ocupa 4 bytes y tiene alrededor de 6-7 dígitos de precisión total
        float variableFloat = 321.34f;
        //debe llevar una f al final de la literal
        System.out.println(variableFloat);

        // double -> ocupa 8 bytes y tiene alrededor de 15-16 dígitos de precisión total
        double variableDouble = 321.34;
        System.out.println(variableDouble);

        // boolean -> almacena solo 2 valores posibles (true y false) 
        boolean variableBoolean = true;
        System.out.println(variableBoolean);

        // char -> ocupa 2 bytes y almacena un número entero que representa a un caracter de la tabla UNICODE
        // UNICODE es un estándar de codificación de caracteres a nivel mundial
        char variableChar = 65;
        System.out.println(variableChar);
        // también se puede almacenar el caracter directamente, encerrado entre comillas simples
        variableChar = 'B';
        System.out.println(variableChar);

        // ** String **
        //  no es un tipo de dato primitivo, es una clase. Representa una cadena de caracteres.
        String variableString = "Hola a todos.";
        System.out.println(variableString);

        // tipos de datos VAR (inferencia de tipos)
        // aparecen a partir del JDK 10
        // No es un tipo de datos en sí mismo. Es una palabra clave del lenguaje que le indica al compilador
        // que infiera el tipo de dato a partir de la primera asignación de valor.
        var var1 = 100; // al poner número entero, lo toma directamente como un int
        var var2 = 'c'; // char
        var var3 = "c"; // String
        var var4 = 100L; // long
        var var5 = 23.23; // double
        var var6 = 23.23f; // float
        var var7 = true; // boolean

        //este tipo de datos solo puede ser usado en variables locales, no puede ser usado como parámetro
        //de método ni como atributo de clase. No se puede declarar un var sin asignar un valor.
        //No es un tipo de dato dinámico. No se puede reasignar la variable a un tipo de dato distinto luego.

        // ## Concatenación de cadenas

        // Operador de concatenación +
        String nombre = "Esteban";
        System.out.println("Hola " + nombre);
        String apellido = "Quito";
        System.out.println("Hola " + nombre + " " + apellido);

        // método String.format()
        // permite formatear cadenas
        int edad = 24;
        String mensaje = String.format("Hola, mi nombre es %s y mi apellido es %s y tengo %d años", nombre, apellido, edad);
        System.out.println(mensaje);

        /*
        Usa los siguientes marcadores de posición:
        %s -> cadenas de texto
        %d -> números enteros
        %f -> números decimales
        %n -> salto de línea
        */

        // método System.out.printf()
        // se utiliza para imprimir directamente con formato
        System.out.printf("Hola, mi nombre es %s y tengo %d años", nombre, edad);
        System.out.println();

        // ## Operadores
        // Operadores aritméticos
        /*
            + suma
            - resta
            * multiplicación
            / división
            % módulo o resto de la división
            Son operadores binarios porque necesitan de 2 operandos.
            Los operandos son numéricos y el resultado es numérico.
        */

        // Operadores de asignación
        /*
            =  asignación
            += suma y asignación
            -= resta y asignación
            *= multiplicación y asignación
            /= división y asignación
            %= resto y asignación
            Son operadores binarios.
            Asignan un valor a la variable y se la modifican utilizando una expresión.
        */
        int numero = 2;
        numero += 3; // numero = numero + 3;
        System.out.println(numero);

        // Operadores incrementales y decrementales
        /*
            ++ incremento en 1
            -- decremento en 1
            Puede utilizarse de dos formas:
            Prefijo (++X o --X): La variable se modifica antes de que se use su valor en la expresión.
            Postfijo (X++ o X--): La variable se modifica después de que se use su valor en la expresión.
            Son operadores unarios, trabajan con un solo operando.
        */

        // Operadores relacionales
        /*
            >  mayor
            <  menor
            >= mayor o igual
            <= menor o igual
            == igual
            != distinto
            Son operadores binarios.
            Los operandos son numéricos y el resultado es booleano.
        */

        // Operadores lógicos
        /*
            & AND (y lógico)
            | OR (es un o lógico)
            ! NOT (negación)
            Los operandos son booleanos.
            El resultado es booleano.
        */

        /*
            Un solo operador lógico & o | evalúa ambas condiciones.
            Al utilizar dos operadores && o || si con una condición determina el valor de verdad, no evalúa 
            la condición que sigue.            
        */

            

    }
    
}