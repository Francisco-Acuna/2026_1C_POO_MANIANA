package ar.org.centro8.java.curso.poo_clase_05;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PooClase05Application {

	public static void main(String[] args) {
		SpringApplication.run(PooClase05Application.class, args);
	}

}
