package ar.org.centro8.java.curso.poo_clase_05;

public class Auto {
    //una clase es una plantilla o molde que define los atributos y métodos que tendrán los objetos

    //atributos
    //definimos los atributos o propiedades (son variables que indican las características)
    String marca;
    String modelo;
    String color;
    int velocidad;

    //métodos
    //definimos los métodos (son bloques de código que definen el comportamiento del objeto)
    void acelerar(){
        velocidad += 10;
    }

    void frenar(){
        velocidad -= 10;
    }

    //sobrecarga de métodos
    //se da cuando un método tiene el mismo nombre que otro existente pero cambia la cantidad y/o tipo de parámetros

    void acelerar(int kilometros){
        velocidad += kilometros;
    }

    /**
     * Este método incrementa la velocidad en la cantidad de kilómetros ingresados.
     * Si el turbo es true, incrementa el doble de la velocidad
     * @param kilometros -> cantidad de kilómetros a incrementar
     * @param turbo -> si es true, incrementa el doble de kilómetros
     */
    void acelerar(int kilometros, boolean turbo){
        if(turbo){
            velocidad += kilometros * 2;
        }else{
            velocidad += kilometros;
        }
    }


}
