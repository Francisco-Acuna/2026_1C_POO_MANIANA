package ar.org.centro8.java.curso.poo_clase_05;

public class TestClass {
    public static void main(String[] args) {
        
        //creamos un objeto de la clase Auto
        Auto auto1 = new Auto();
        //un objeto es una instancia de una clase, es decir, una entidad con características (atributos)
        //y comportamiento (métodos)

        //le damos estado al objeto (dar estado es completar el valor de sus atributos)
        auto1.marca = "Fiat";
        auto1.modelo = "Fiorino";
        auto1.color = "Blanco";
        auto1.velocidad = 0;

        //ver el estado del objeto
        System.out.println(auto1.marca);
        System.out.println(auto1.modelo);
        System.out.println(auto1.color);
        System.out.println(auto1.velocidad);

        //utilizamos los métodos de la clase
        auto1.acelerar(); // 10
        System.out.println(auto1.velocidad); // 10

        auto1.acelerar(); // +10 = 20
        auto1.acelerar(); // +10 = 30
        auto1.frenar(); // -10 = 20
        System.out.println(auto1.velocidad); //20

        System.out.println();

        auto1.acelerar(15, true);

    }
}
