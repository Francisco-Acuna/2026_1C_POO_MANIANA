public class Clase01 {
    public static void main(String[] args) {
        
        /*
        Instituto: Centro de Formación Profesional N°8 - SMATA
        Curso: Programación Orientada a Objetos
        Lenguaje principal: Java
        Cursada: lunes, miércoles y viernes de 10 a 13.30hs.
        Profesor: Francisco Acuña
        Email: franciscoacuna.centro8@gmail.com
        Repositorio: https://github.com/Francisco-Acuna/2026_1C_POO_MANIANA
        Softwares necesarios:
            - JDK (sugerido 21 o 17) -> https://www.oracle.com/latam/java/technologies/downloads/#java21
            - Visual Studio Code -> https://code.visualstudio.com/download
            - Extension de VSC -> Extension Pack for Java (by Microsoft)
            - MySQL y Workbench -> https://www.mysql.com/downloads/
        */

        // comentario en línea
        
        /*
            comentarios 
            en bloque
            (varias líneas)
        */

        /**
         * comentarios del tipo
         * JavaDoc
         * en bloque
         */

        //etiquetas en los comentarios

        // TODO indican tareas pendientes por implementar o finalizar

        // FIXME señala los errores o problemas que deben ser corregidos

        // instalar extensión TODO TREE by Gruntfuggly

        //impresión por consola
        System.out.println("Hola Mundo!");
        // sout + tab (atajo de teclado para impresión por consola)

        //declaración de variable
        int variable; //declaración de variable con tipo de dato e identificador
        variable = 10; //asignación de valor a la variable
        int variable2 = 10; //declaración y asignación en línea
        int variable3=10, variable4=20, variable5=30; //declaración y asignación múltiple en línea
        
        /*
            Java es un lenguaje fuertemente tipado, por lo cual se deben respetar ciertos puntos:
            - No se puede asignar otro tipo de dato como valor a una variable ya declarada.
            - No se puede cambiar el tipo de dato de una variable ya declarada.
            - No se puede crear otra variable con el mismo nombre.
            - Una variable puede tener una única declaración.
            - Una variable puede tener innumerables valores, siempre que sean del mismo tipo de dato.
        */




    }
    
}